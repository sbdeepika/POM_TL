package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

//import pages.EditLeadPage;
import pages.LoginPage;
//import pages.ViewLeadPage;
import wrappers.OpentapsWrappers;

public class TC002_EditLead extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Edit Lead";
		testDescription="Login To Opentaps and Edit Lead";
		browserName="chrome";
		dataSheetName="TC002_EditLead";
		category="Sanity";
		authors="Sneha";
	}

	@Test(dataProvider="fetchData")
	public void edit(String userName, String passWord, String fName,String subHeadingMarketingCampaign, String addMarketingCampaign, 
			String subHeadingSource, String addSource){

		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.enterLeadFirstName(fName)
		.clickFindLeadsButton()
		.clickSearchLeadID()
		.viewLeadFirstName(fName)
		.clickeditbutton()
		.verifyMarketingCampaign(subHeadingMarketingCampaign)
		.addMarketingCampaign(addMarketingCampaign)
		.verifySource(subHeadingSource)
		.addSource(addSource)
		.clickUpdateButton();
		
	}

}