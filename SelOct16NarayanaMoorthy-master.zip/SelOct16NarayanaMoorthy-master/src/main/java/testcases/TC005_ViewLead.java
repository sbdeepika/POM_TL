package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

//import pages.EditLeadPage;
import pages.LoginPage;
//import pages.ViewLeadPage;
import wrappers.OpentapsWrappers;

public class TC005_ViewLead extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="View Lead";
		testDescription="Login To Opentaps and View Lead";
		browserName="chrome";
		dataSheetName="TC005_ViewLead";
		category="Sanity";
		authors="Tamil";
	}

	@Test(dataProvider="fetchData")
	public void view(String userName, String passWord, String fName,String addMarketingCampaign, 
			String addSource){

		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.enterLeadFirstName(fName)
		.clickFindLeadsButton()
		.clickSearchLeadID()
		.viewLeadFirstName(fName)
		.viewMarketingCampaign(addMarketingCampaign)
		.viewSource(addSource);
		
	}

}