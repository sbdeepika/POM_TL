package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.CreateLeads;
import pages.LoginPage;
import wrappers.OpentapsWrappers;

public class TC007_DuplicateLead extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="duplicate lead";
		testDescription="Login into Opentaps and create a duplicate lead";
		browserName="chrome";
		dataSheetName="TC007_DuplicateLead";
		category="Smoke";
		authors="Vino";
	}
	
	@Test(dataProvider="fetchData")
	public void login(String userName, String passWord,String EmailAddress) throws InterruptedException{

		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.switchtoEmailTab()
		.enterEmail(EmailAddress)
		.clickFindLeadsButton()
		.clickfirstresulting()
		.clickduplicate()
		.ClickDuplicateCreateLead();
		
		
		

	}

}