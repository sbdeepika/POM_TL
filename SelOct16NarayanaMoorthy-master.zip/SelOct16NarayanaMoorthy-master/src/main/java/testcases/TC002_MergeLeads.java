package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.OpentapsWrappers;

public class TC002_MergeLeads extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Merge";
		testDescription="Merge lead";
		browserName="chrome";
		dataSheetName="TC004_MergeLead";
		authors="Suresh";
		category="Smoke";
	}

	@Test(dataProvider="fetchData")
	public void login(String userName, String passWord,
			String fromleadID, String toleadID)
	{
		
		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		//.verifyUserName(loginName)
		.clickCRMSFA()
     	.clickLeads()
     	.clickMergeLead()
		.clickFromLeadIcon()
		.enterLeadID(fromleadID)
		.clickFindLeadsButton()
	    .clickLeadId(fromleadID)
		.clickToLeadIcon()
		.enterLeadID(toleadID)
		.clickFindLeadsButton()
		.clickLeadId(toleadID)
		.clickMergeButton();
	//	.viewLeadFirstName(fName)
		
		
			
	}
			
	}


