package testcases;

	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;

	import pages.LoginPage;
	import wrappers.OpentapsWrappers;

public class TC001_CreateLead extends OpentapsWrappers{

		@BeforeClass
		public void setData() {
			testCaseName="Create";
			testDescription="Login into Opentaps and Create a lead";
			browserName="chrome";
			authors="Chittu";
			dataSheetName="TC001_CreateLead";
			category="Smoke";
		}

		@Test(dataProvider="fetchData")
		public void login(String userName, String passWord,String coName,String fName,String lName,String Industry,String Owner){

			new LoginPage(driver, test)
			.enterUserName(userName)
			.enterPassword(passWord)
			.clickLogin()
			.clickCRMSFA()
			.clickLeads()
			.clickcreatelead()
			.enterCompanyName(coName)
			.enterFirstName(fName)
			.enterLastName(lName)
			.choseindustry(Industry)
			.choseownership(Owner)
			.ClickCreateLead()
			.viewLeadFirstName(fName);

		}

	}