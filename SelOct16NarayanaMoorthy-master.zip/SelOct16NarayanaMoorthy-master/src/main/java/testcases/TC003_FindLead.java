package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.OpentapsWrappers;

public class TC003_FindLead extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Find Leads";
		testDescription="To Find a Lead and Verify if not present";
		browserName="chrome";
		dataSheetName="TC003_FindLead";
		category="Smoke";
		authors="Lakshmi";
	}

	@Test(dataProvider="fetchData")
	public void login(String userName, String passWord, String Leadfname, String phonenum ){

		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.enterLeadFirstName(Leadfname)
		.clickFindLeadsButton()
		.switchtoPhoneTab()
		.enterPhoneNum(phonenum)
		.clickFindLeadsButton()
		.verifyErrorMessage();
	}
}