package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.MyLeads;
import wrappers.OpentapsWrappers;

public class TC004_MergeLead extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="MergeLead";
		testDescription="Merge Lead";
		browserName="chrome";
		dataSheetName="TC004_MergeLead";
		category="Sanity";
		authors="Siva";
	}
	
	@Test(dataProvider="fetchData")
	public void mergelead(String userName, String passWord,	String fromleadID, String toleadID ){

	MyLeads leads=
		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads();
	leads.clickMergeLead()
		.clickFromLeadIcon()
		.enterLeadID(fromleadID)
		.clickFindLeadsButton()
		.clickLeadId(fromleadID)
		.clickToLeadIcon()
		.enterLeadID(toleadID)
		.clickFindLeadsButton()
		.clickLeadId(toleadID)
		.clickMergeButton();
	leads.clickFindLeads()
		.enterLeadID(fromleadID)
		.clickFindLeadsButton()
		.verifyErrorMessage();
	
	}
	
}