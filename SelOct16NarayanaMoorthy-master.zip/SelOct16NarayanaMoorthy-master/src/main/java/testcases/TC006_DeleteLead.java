package testcases;


import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.OpentapsWrappers;

public class TC006_DeleteLead extends OpentapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Delete Lead";
		testDescription="Deleting the Lead";
		browserName="chrome";
		dataSheetName="TC006_DeleteLead";
		category="Regression";
		authors="Singaravel";

	}

	@Test(dataProvider="fetchData")
	public void login(String userName, String passWord,String pNumber){

		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.switchtoPhoneTab()
		.enterPhoneNum(pNumber)
		.clickFindLeadsButton()
		.clickfirstresulting()
		.clickdelete();

	}

}