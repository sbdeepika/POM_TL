package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class FindLeads extends OpentapsWrappers  {

	public FindLeads(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Find Leads")){
			reportStep("This is not My FindLeads page", "FAIL");
		}
	}
		
public FindLeads clickFindLeadsButton(){
		
	    clickByLink("Merge Leads");
	    switchToLastWindow();
		return new FindLeads(driver, test);
		
	}
		
	
	

}
