package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class ViewLead extends OpentapsWrappers {

	public ViewLead(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("View Lead | opentaps CRM")){
			reportStep("This is not View Lead Page", "FAIL");
		}

	}

	public ViewLead viewLeadFirstName(String fName)
	{
		verifyTextContainsById("viewLead_firstName_sp", fName);
		return this;
	}
	public EditLead clickeditbutton()
	{
		clickByLink("Edit");
		return new EditLead(driver, test);
	}

	public ViewLead viewSource(String addSource)
	{
		verifyTextContainsById("viewLead_dataSources_sp", addSource);
		return this;
	}
	public ViewLead viewMarketingCampaign(String addMarketingCampaign)
	{
		verifyTextContainsById("viewLead_marketingCampaigns_sp", addMarketingCampaign);
		return this;
	}

	public ViewLead clickduplicate() {
		clickByLink("Duplicate Lead");
		//System.out.println("duplicate");
		//return new CreateLeads(driver, test);
		return this;
		}
	  public ViewLead ClickDuplicateCreateLead() {
		//Thread.sleep(1000);
		clickByXpath("//input[@name='submitButton']");
		//clickByName("submitButton");
		return new ViewLead(driver,test);
	}

	public ViewLead clickdelete(){
		clickByClassName("subMenuButtonDangerous");
		return this;	
	}
}