package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class EditLead extends OpentapsWrappers{

	public EditLead(RemoteWebDriver driver, ExtentTest test)
	{
		this.driver=driver;
		this.test=test;
		if(!verifyTitle("opentaps CRM"))
		{
			reportStep("This is not Edit Lead Page", "FAIL");
		}
	}
	public EditLead verifyMarketingCampaign(String subHeadingMarketingCampaign)
	{
		verifyTextContainsByXpath("(//div[@class='subSectionTitle'])[2]", subHeadingMarketingCampaign);
		return this;
	}
	public EditLead addMarketingCampaign(String addMarketingCampaign)
	{
		selectVisibileTextById("addMarketingCampaignForm_marketingCampaignId", addMarketingCampaign);
		clickByXpath("(//input[@class='smallSubmit'])[3]");
		return this;
	}
	public EditLead verifySource(String subHeadingSource)
	{
		verifyTextContainsByXpath("(//div[@class='subSectionTitle'])[1]", subHeadingSource);		
		return this;
	}
	public EditLead addSource(String addSource)
	{
		selectVisibileTextById("addDataSourceForm_dataSourceId", addSource);
		clickByXpath("(//input[@class='smallSubmit'])[2]");
		return this;
	}
	public ViewLead clickUpdateButton()
	{
		clickByXpath("(//input[@class='smallSubmit'])[1]");
		return new ViewLead(driver, test);
	}


}
