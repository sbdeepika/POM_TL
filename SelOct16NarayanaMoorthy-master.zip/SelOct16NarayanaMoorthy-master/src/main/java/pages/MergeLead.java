package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class MergeLead extends OpentapsWrappers {

	public MergeLead(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Merge Leads | opentaps CRM")){
			reportStep("This is not Merge Leads Page", "FAIL");
		}
	}

	public FindMergeLead clickFromLeadIcon(){
		clickByXpath("//span[text()='From Lead']/following::img[1]");
		switchToLastWindow();
		return new FindMergeLead(driver, test);
	}

	public FindMergeLead clickToLeadIcon(){
		//
		clickByXpath("//span[text()='To Lead']/following::img[1]");
		switchToLastWindow();
		return new FindMergeLead(driver, test);
	}

	public ViewLead clickMergeButton(){
		clickByLinkWithoutSnap("Merge");
		acceptAlert();
		reportStep("Alert accepted successfully, View Lead opened  ", "PASS");
		return new ViewLead(driver, test);
	}

}