package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class MyLeads extends OpentapsWrappers  {

	public MyLeads(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("My Leads | opentaps CRM")){
			reportStep("This is not My Leads Page", "FAIL");
		}
	}
	
	public CreateLeads clickcreatelead(){
		clickByLink("Create Lead");
		return new CreateLeads(driver,test);
	}
	
	public MergeLead clickMergeLead(){
		clickByLink("Merge Leads");
		return new MergeLead(driver, test);
	}
	public FindLead clickFindLeads(){
		clickByLink("Find Leads");
		return new FindLead(driver, test);
	}
}