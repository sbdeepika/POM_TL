package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class FindMergeLead extends OpentapsWrappers{
	
	public FindMergeLead(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Find Leads")){
			reportStep("This is not Find Leads Page", "FAIL");
		}
		
	}	
		
	public FindMergeLead enterLeadID(String leadID){
		enterByName("id", leadID );
		return this;
	}
	
	public MergeLead clickLeadId(String leadID) {
		clickByLinkWithoutSnap(leadID);
		switchToParentWindow();
		//Thread.sleep(2000);
		return new MergeLead(driver, test);
	}
	
	public FindMergeLead clickFindLeadsButton() {
		clickByXpath("//button[text()='Find Leads']");
		try{
			Thread.sleep(4000);
		}
		catch(InterruptedException e){
			
		}
		return this;
	}

}