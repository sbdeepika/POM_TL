package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class FindLead extends OpentapsWrappers{

	public FindLead(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Find Leads | opentaps CRM")){
			reportStep("This is not Find Leads Page", "FAIL");
		}

	}

	public FindLead enterLeadID(String fromleadID){
		enterByName("id", fromleadID );
		return this;
	}
	public FindLead enterLeadFirstName(String Leadfname){
		enterByXpath("(//input[@name = 'firstName'])[3]", Leadfname);
		return this;
	}

	public FindLead verifyLeadsnotfound(){
		verifyTextByXpath("//div[@class = 'x-paging-info']", "No records to display");
		return this;
	}

	public FindLead switchtoPhoneTab(){
		clickByXpath("//span[contains(text(),'Phone')]");
		return this;
	}

	public FindLead enterPhoneNum(String phonenum){
		enterByName("phoneNumber", phonenum);
		return this;
	}

	public FindLead switchtoEmailTab(){
		clickByXpath("//span[contains(text(),'Email')]");
		return this;
	}
	
	public FindLead enterEmail(String emailaddress){
		enterByName("emailAddress",emailaddress );
		return this;
		}
	
	public FindLead clickFindLeadsButton() {
		clickByXpath("//button[text()='Find Leads']");
		try{
			Thread.sleep(4000);
		}
		catch(InterruptedException e){

		}
		return this;
	}
	
	public ViewLead clickSearchLeadID()
	{
		String str = getTextByXpath("(//a[@class='linktext'])[4]");
		String str2 = getTextByXpath("//a[text()='"+str+"'][1]");
		clickByLink(str2);
		return new ViewLead(driver, test);
	}

	public FindLead verifyErrorMessage() {
		verifyTextByXpath("//div[text()='No records to display']","No records to display");
		return this;

	}
	
	public ViewLead clickfirstresulting(){
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)");
		return new ViewLead(driver, test);
		}
}
