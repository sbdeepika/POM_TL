package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.OpentapsWrappers;

public class CreateLeads extends OpentapsWrappers{
	public CreateLeads(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
	
		if(!verifyTitle("Create Lead | opentaps CRM")){
			reportStep("This is not Create Lead Page", "FAIL");
		}
	}
		public CreateLeads enterCompanyName(String data){
			enterById("createLeadForm_companyName", data);
			return this;
		}
		
		public CreateLeads enterFirstName(String firstName){
			enterById("createLeadForm_firstName",firstName);
			return this;
		}
		
		public CreateLeads enterLastName(String lastName){
			enterById("createLeadForm_lastName", lastName);
			return this;
		}
		
		public CreateLeads choseindustry(String industry){
			selectVisibileTextById("createLeadForm_industryEnumId", industry);
			return this;
		}
		public CreateLeads choseownership(String owner){
			selectVisibileTextById("createLeadForm_ownershipEnumId", owner);
			return this;
		}
		
		public ViewLead ClickCreateLead() {
			//Thread.sleep(1000);
			//clickByXpath("//input[@name='submitButton']");
			clickByName("submitButton");
			return new ViewLead(driver,test);
		}
		
	
}